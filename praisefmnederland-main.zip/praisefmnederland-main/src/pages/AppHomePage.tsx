import React, { useState, useEffect, useMemo } from 'react';
import { Play, Pause, ChevronRight, Volume2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

import { SCHEDULES } from '../constants';

// Alterado para o fuso horário de Amsterdã
const getAmsterdamTime = () => {
  const now = new Date();

  const amsterdamDate = new Date(
    now.toLocaleString('nl-NL', { timeZone: 'Europe/Amsterdam' })
  );

  return {
    hours: amsterdamDate.getHours(),
    minutes: amsterdamDate.getMinutes(),
    day: amsterdamDate.getDay(),
    totalMinutes: amsterdamDate.getHours() * 60 + amsterdamDate.getMinutes()
  };
};

// Alterado para formato 24h (padrão holandês)
const format24h = (time24: string) => {
  const [h, m] = time24.split(':').map(Number);
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
};

const AppHomePage: React.FC = () => {
  const navigate = useNavigate();

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(getAmsterdamTime());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(getAmsterdamTime());
    }, 30000);

    return () => clearInterval(timer);
  }, []);

  const todaySchedule = useMemo(() => {
    return SCHEDULES[currentTime.day] || SCHEDULES[1];
  }, [currentTime.day]);

  const currentProgram = useMemo(() => {
    return todaySchedule.find((program) => {
      const [sH, sM] = program.startTime.split(':').map(Number);
      const [eH, eM] = program.endTime.split(':').map(Number);

      const start = sH * 60 + sM;
      let end = eH * 60 + eM;

      if (end === 0 || end <= start) end = 24 * 60;

      return currentTime.totalMinutes >= start && currentTime.totalMinutes < end;
    });
  }, [todaySchedule, currentTime.totalMinutes]);

  return (
    <div className="min-h-screen bg-white dark:bg-black text-black dark:text-white pb-24">
      <header className="border-b border-gray-200 dark:border-white/10 py-4 px-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-[#ff6600] text-white font-bold flex items-center justify-center text-sm rounded">
              P
            </div>
            <div className="w-8 h-8 bg-[#ff6600] text-white font-bold flex items-center justify-center text-sm rounded">
              F
            </div>
            <div className="w-8 h-8 bg-[#ff6600] text-white font-bold flex items-center justify-center text-sm rounded">
              M
            </div>
          </div>

          <button
            onClick={() => navigate('/profile')}
            className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-semibold text-sm"
          >
            R
          </button>
        </div>
      </header>

      <section className="py-6">
        <div className="flex space-x-4 overflow-x-auto no-scrollbar px-4 pb-4">
          {todaySchedule.map((program) => {
            const isLive = currentProgram?.id === program.id;

            return (
              <div key={program.id} className="flex-shrink-0 relative">
                <div
                  className={`w-40 h-40 rounded-full overflow-hidden border-4 ${
                    isLive ? 'border-[#ff6600]' : 'border-white dark:border-black'
                  } shadow-lg relative ${isLive ? 'animate-pulse' : ''}`}
                >
                  <img
                    src={program.image}
                    alt={program.title}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.src = '/logo.png';
                    }}
                  />

                  <div className="absolute bottom-2 right-2 w-10 h-10 bg-black dark:bg-white rounded-full flex items-center justify-center border-2 border-white dark:border-black">
                    <span className="text-white dark:text-black text-lg font-bold">
                      1
                    </span>
                  </div>
                </div>

                {isLive && (
                  <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-black dark:bg-white text-white dark:text-black px-4 py-1 text-xs font-bold uppercase whitespace-nowrap">
                    LIVE
                  </div>
                )}

                <div className="text-center mt-3 max-w-[160px]">
                  <p className="text-xs font-semibold truncate">
                    {program.title}
                  </p>

                  <p className="text-[10px] text-gray-500 dark:text-gray-400">
                    {format24h(program.startTime)} - {format24h(program.endTime)}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <section className="px-6 py-4">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-1">
            Praise FM Nederland
          </h1>

          {currentProgram && (
            <p className="text-gray-500 dark:text-gray-400 mb-4">
              {currentProgram.title}{' '}
              {currentProgram.host !== 'Praise FM' &&
                currentProgram.host !== 'Praise FM NL' &&
                `met ${currentProgram.host}`}
            </p>
          )}

          <button
            onClick={() => navigate('/schedule')}
            className="border-2 border-black dark:border-white text-black dark:text-white px-8 py-2 font-semibold hover:bg-black hover:text-white dark:hover:bg-white dark:hover:text-black transition-colors flex items-center justify-center mx-auto space-x-2 rounded-sm"
          >
            <span>Programmering & Schema's</span>
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </section>

      <section className="px-6 py-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold">Recent Gedraaid</h2>
          <button className="text-sm text-gray-600 dark:text-gray-400">
            Bekijk alles
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex items-center space-x-4 p-3 hover:bg-gray-50 dark:hover:bg-white/5 rounded-lg transition-colors cursor-pointer">
            <div className="w-20 h-20 flex-shrink-0 rounded overflow-hidden bg-gray-200 dark:bg-white/10">
              <div className="w-full h-full flex items-center justify-center">
                <Volume2 className="w-8 h-8 text-gray-400" />
              </div>
            </div>

            <div className="flex-grow min-w-0">
              <h3 className="font-bold text-base truncate">
                Ochtend Worship Mix
              </h3>

              <p className="text-sm text-gray-600 dark:text-gray-400 truncate">
                Hedendaagse Christelijke Muziek
              </p>

              <div className="mt-2 flex items-center space-x-2">
                <div className="flex-grow h-1 bg-gray-200 dark:bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#ff6600]"
                    style={{ width: '45%' }}
                  />
                </div>

                <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">
                  2 uur geleden
                </span>
              </div>
            </div>

            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-12 h-12 rounded-full bg-black dark:bg-white flex items-center justify-center flex-shrink-0"
            >
              <Play className="w-5 h-5 text-white dark:text-black fill-current ml-0.5" />
            </button>
          </div>
        </div>
      </section>

      {isPlaying && (
        <div className="fixed bottom-16 left-0 right-0 bg-black dark:bg-white text-white dark:text-black px-4 py-3 flex items-center justify-between shadow-lg">
          <div className="flex items-center space-x-3 flex-grow min-w-0">
            <div className="w-2 h-2 bg-[#ff6600] rounded-full animate-pulse" />

            <div className="min-w-0">
              <p className="font-semibold text-sm truncate">
                {currentProgram?.title || 'Praise FM Nederland'}
              </p>

              <p className="text-xs opacity-70 truncate">
                {currentProgram?.host &&
                currentProgram.host !== 'Praise FM' &&
                currentProgram.host !== 'Praise FM NL'
                  ? `met ${currentProgram.host}`
                  : 'Live Streaming'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsPlaying(false)}
            className="w-10 h-10 rounded-full border-2 border-white dark:border-black flex items-center justify-center flex-shrink-0"
          >
            <Pause className="w-4 h-4 fill-current" />
          </button>
        </div>
      )}

      <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-black border-t border-gray-200 dark:border-white/10 px-4 py-2 shadow-lg">
        <div className="flex items-center justify-around">
          <button
            onClick={() => navigate('/app')}
            className="flex flex-col items-center py-2 text-[#ff6600]"
          >
            <svg className="w-6 h-6 mb-1" fill="currentColor" viewBox="0 0 24 24">
              <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" />
            </svg>
            <span className="text-xs font-semibold">Home</span>
          </button>

          <button
            onClick={() => navigate('/music')}
            className="flex flex-col items-center py-2 text-gray-500 dark:text-gray-400"
          >
            <svg className="w-6 h-6 mb-1" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z" />
            </svg>
            <span className="text-xs font-semibold">Muziek</span>
          </button>

          <button
            onClick={() => navigate('/schedule')}
            className="flex flex-col items-center py-2 text-gray-500 dark:text-gray-400"
          >
            <svg className="w-6 h-6 mb-1" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17 10H7v2h10v-2zm2-7h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11z" />
            </svg>
            <span className="text-xs font-semibold">Programmering</span>
          </button>

          <button
            onClick={() => navigate('/my-sounds')}
            className="flex flex-col items-center py-2 text-gray-500 dark:text-gray-400"
          >
            <svg className="w-6 h-6 mb-1" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
            </svg>
            <span className="text-xs font-semibold">Mijn Geluiden</span>
          </button>

          <button className="flex flex-col items-center py-2 text-gray-500 dark:text-gray-400">
            <svg className="w-6 h-6 mb-1" fill="currentColor" viewBox="0 0 24 24">
              <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" />
            </svg>
            <span className="text-xs font-semibold">Zoeken</span>
          </button>
        </div>
      </nav>
    </div>
  );
};

export default AppHomePage;